from Equation import Expression

fun = Expression("sin(x^2)",["x"])
print(fun(4))